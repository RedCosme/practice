from setuptools import setup

setup(
    name        = 'y_nester',
    version     = '1.1.0',
    py_modules  = ['y_nester'],
    author      = 'cosmic',
    author_email= 'yangguanyu_2006@126.com',
    url         = '',
    description = 'A simple printer of nested lists',
)
